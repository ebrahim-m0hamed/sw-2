package com.example.slabiak.appointmentscheduler.exception;

public class AppointmentNotFoundException extends RuntimeException {
}
