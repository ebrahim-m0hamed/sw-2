package com.example.slabiak.appointmentscheduler.entity;

public enum ExchangeStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    EXPIRED
}


