package com.example.slabiak.appointmentscheduler.dao.user;

import com.example.slabiak.appointmentscheduler.entity.user.User;

public interface UserRepository extends CommonUserRepository<User> {
}
