package com.example.slabiak.appointmentscheduler.exception;

public class WorkNotFoundException extends RuntimeException {
}
