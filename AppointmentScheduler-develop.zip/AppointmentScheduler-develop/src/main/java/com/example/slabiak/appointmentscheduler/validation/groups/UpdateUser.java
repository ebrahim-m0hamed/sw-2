package com.example.slabiak.appointmentscheduler.validation.groups;

public interface UpdateUser {
}
