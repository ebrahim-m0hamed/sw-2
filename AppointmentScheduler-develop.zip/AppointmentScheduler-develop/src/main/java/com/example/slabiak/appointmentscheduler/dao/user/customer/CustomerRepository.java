package com.example.slabiak.appointmentscheduler.dao.user.customer;

import com.example.slabiak.appointmentscheduler.dao.user.CommonUserRepository;
import com.example.slabiak.appointmentscheduler.entity.user.customer.Customer;

public interface CustomerRepository extends CommonUserRepository<Customer> {
}
