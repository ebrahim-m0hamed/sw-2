package com.example.slabiak.appointmentscheduler.exception;

public class InvoiceNotFoundException extends RuntimeException {
}
