package com.example.slabiak.appointmentscheduler.dao.user.customer;

import com.example.slabiak.appointmentscheduler.dao.user.CommonUserRepository;
import com.example.slabiak.appointmentscheduler.entity.user.customer.CorporateCustomer;

public interface CorporateCustomerRepository extends CommonUserRepository<CorporateCustomer> {
}
